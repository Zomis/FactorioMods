package.loaded[...] = {}

local function helper(...)
   -- NYI
end

function embrace(opt)
   local opt = opt or "default"
   return hepler(opt.."?")
end

