foo = {}

function foo.bar()
   baz()
end
